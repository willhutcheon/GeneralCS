package set;

public class SetException extends RuntimeException {

    public SetException() {
        super();
    }

    public SetException(String s) {
        super(s);
    }
}
