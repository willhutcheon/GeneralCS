package question01;

/**
 *
 * @author willh
 */

// initializing the enumerated color variable with some options for cat colors
public enum Color {
    WHITE, BLACK, ORANGE, WHITE_ORANGE, WHITE_BLACK, BLACK_ORANGE;
}