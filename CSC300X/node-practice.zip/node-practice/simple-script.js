function printPoem() {
    console.log('Roses are red,');
    console.log('Violets are blue,');
    console.log('Sugar is sweet,');
    console.log('And so are you.');
    console.log();
}
printPoem();
printPoem();
"use strict";
const express = require("express");
const app = express();
app.get("/", function (req, res) {
    res.send("Hello, World from Express!");
});
app.listen(3000, function () {
    console.log('Example app listening on port 3000!');
})