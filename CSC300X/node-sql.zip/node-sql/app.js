//app.js
'use strict';
const express = require('express');
const app = express();
const sqlite3 = require('sqlite3');
const sqlite = require('sqlite');
const multer = require('multer');
app.use(multer().none());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
const INVALID_PARAM_ERROR = 400;
const SERVER_ERROR = 500;
const SERVER_ERROR_MSG = 'Something went wrong on the server.';

app.get('/menu/subcategory', async function (req, res) {
    try {
        let qry = 'SELECT name, subcategory, price, id FROM menu ORDER BY id;';
        let db = await getDBConnection();
        let menu = await db.all(qry);
        await db.close();
        // res.json(menu);
        let firstRow = menu[0];
        let response = 'The first object is = Name: ' + firstRow.name + '(' + firstRow.price + ')';
        res.type("text");
        res.send(response);
    } catch (err) {
        res.type('text');
        res.status(SERVER_ERROR).send(SERVER_ERROR_MSG);
    }
});

app.post('/menu/add', async (req, res) => {
    try {
        let query =
            'INSERT INTO menu ("id","name","category","subcategory","price","cost") ' +
            'VALUES(40, "newName", "newCategory", "newSubcategory", 10, 5.20);';
        let db = await getDBConnection();
        await db.exec(query);
        await db.close();
        res.type("text");
        res.send("successfully inserted into table");
    } catch (err) {
        res.status(SERVER_ERROR).send(SERVER_ERROR_MSG);
    }
});

app.get('/menu/price', async function (req, res) {
    try {
        let qry = 'SELECT name, price FROM menu ORDER BY name LIMIT 3;';
        let db = await getDBConnection();
        let result = await db.get(qry);
        await db.close();
        res.json(result);
    } catch (err) {
        res.type('text');
        res.status(SERVER_ERROR).send(SERVER_ERROR_MSG);
    }
});

app.post('/menu/addAnother', async (req, res) => {
    try {
        let query =
            'INSERT INTO menu ("id","name","category","subcategory","price","cost") ' +
            'VALUES(41, "anotherName", "anotherCategory", "anotherSubcategory", 20.99, 9.50);';
        let db = await getDBConnection();
        let result = await db.run(query);
        await db.close();
        res.json(result);
    } catch (err) {
        res.status(SERVER_ERROR).send(SERVER_ERROR_MSG);
    }
});

// Gets all menu items (JSON) in a given :category.
app.get('/menu/category/:category', async function (req, res) {
    try {
        let qry = 'SELECT name, subcategory, price FROM menu WHERE category =? ORDER BY name;';
        let db = await getDBConnection();
        let menu = await db.all(qry, req.params.category);
        await db.close();
        if (menu.length === 0) {
            res.type('text');
            res.status(INVALID_PARAM_ERROR).send('There are no records for that category!');
        } else {
            res.json(menu);
        }
    } catch (err) {
        res.type('text');
        res.status(SERVER_ERROR).send(SERVER_ERROR_MSG);
    }
});

app.post('/menu/addPlaceholder', async (req, res) => {
    let id = parseInt(req.body.id);
    let name = req.body.name;
    let category = req.body.category;
    let subcategory = req.body.subcategory;
    let price = parseFloat(req.body.price);
    let cost = parseFloat(req.body.cost);
    if (id && name && category && subcategory && price && cost) {
        try {
            let query = 'INSERT INTO menu ("id","name","category","subcategory","price","cost") ' +
                'VALUES(?, ?, ?, ?, ?, ?); ';
            let db = await getDBConnection();
            let params = [id, name, category, subcategory, price, cost];
            await db.run(query, params);
            await db.close();
            res.type("text");
            res.send("Successfully added a row");
        }
        catch (err) {
            res.status(SERVER_ERROR).send(err);
        }
    }
    else {
        response.status(INVALID_PARAM_ERROR).send("Invalid Request");
    }
});

// /menu/search?term=coffee Returns the name and price of all items where the name matches the user query.
app.get('/menu/search', async function (req, res) {
    if (req.query.term) {
        try {
            let menu = await getSearchResults(req.query.term);
            if (menu.length > 0) {
                res.json(menu)
            } else {
                res.status(INVALID_PARAM_ERROR).type('text').send('There were no matches to that query!');
            }
        } catch (err) {
            res.status(SERVER_ERROR).type('text').send(SERVER_ERROR_MSG);
        }
    } else {
        res.status(INVALID_PARAM_ERROR).type('text').send('Please provide a search query!');
    }
});

async function getSearchResults(term) {
    let qry = 'SELECT name, price FROM menu WHERE name LIKE ?';
    let db = await getDBConnection();
    let menu = await db.all(qry, "%" + term + "%");
    await db.close();
    return menu;
}




/**
* Establishes a database connection to a database and returns the database object.
* Any errors that occur during connection should be caught in the function
* that calls this one.
* @returns {Object} - The database object for the connection.
*/
async function getDBConnection() {
    const db = await sqlite.open({
        filename: 'demo.db',
        driver: sqlite3.Database
    });
    return db;
}
const PORT = process.env.PORT || 8000;
app.listen(PORT);