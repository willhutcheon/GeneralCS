"use strict";
const express = require("express");
const app = express();

app.use(express.static("public"));

// for application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true })); // built-in middleware
// for application/json
app.use(express.json()); // built-in middleware
const multer = require("multer");
// for multipart/form-data (required with FormData)
app.use(multer().none()); // requires the "multer" module

app.get("/", function (req, res) {
    res.send("Hello, World from Express!");
});
let products = [
    {
        id: 1,
        name: "chair",
        type: "furniture",
        price: 120,
        description: "It's for sitting and/or keeping some purgatory laundry"
    },
    {
        id: 2,
        name: "notepad",
        type: "stationery",
        price: 8,
        description: "Size 8X11, college ruled or plain"
    },
    {
        id: 3,
        name: "monitor",
        type: "electronic",
        price: 250,
        description: "Full 4K (2160p)"
    },
    {
        id: 4,
        name: "desk",
        type: "furniture",
        price: 180,
        description: "A standing desk, adjustable height"
    }
];
//Request: http://localhost:3000/products/all
app.get("/products/all", (request, response) => {
    response.json(products);
});
//Request: http://localhost:3000/products/id/1
app.get("/products/id/:id", (request, response) => {
    const productId = Number(request.params.id);
    const getProduct = products.find((product) => product.id === productId);
    if (!getProduct) {
        response.status(500).send("Product not found.");
    } else {
        response.json(getProduct);
    }
});
//Request: http://localhost:3000/products?type=electronic
app.get("/products", (request, response) => {
    let type = request.query.type;
    if (!type) {
        response.json(products);
    }
    else {
        let prodList = products.filter(product => product.type.toLowerCase().includes(type));
        if (!prodList) {
            response.status(500).send("Product not found.");
        } else {
            response.json(prodList);
        }
    }
});

// accept POST request on the homepage
app.post("/", function (request, response) {
    response.send(request.body);
});
app.post('/products/new', function (request, response) {
    const productId = request.body.id;
    const name = request.body.name;
    const type = request.body.type;
    const price = request.body.price;
    const description = request.body.description;
    if (!productId || !name || !type || !price || !description) {
        response.status(400).send("Invalid Request")
    }
    else {
        const incomingProduct = request.body;
        products.push(incomingProduct);
        response.json(products);
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, function () {
    console.log('Example app listening on port: ' + PORT + "!");
});