"use strict";
(function () {
    const MY_SERVER_BASEURL = "/products";
    window.addEventListener("load", init);
    function init() {
        getAllProducts();
    }
    function getAllProducts() {
        let table = id("product-table");
        fetch(MY_SERVER_BASEURL + "/all")
            .then(checkStatus)
            .then((response) => {
                //console.log(response);
                for (const item of response) {
                    let tableRow = table.insertRow();
                    let productIdRow = tableRow.insertCell();
                    let name = tableRow.insertCell();
                    let type = tableRow.insertCell();
                    let price = tableRow.insertCell();
                    let productId = item["id"];
                    let productIdString = "productIdLink" + productId;
                    productIdRow.innerHTML =
                        "<span id='" + productIdString + "'>" + productId + "</span>";
                    let productIdLink = id(productIdString);
                    productIdLink.addEventListener("click", function (event) {
                        getProductById(productId);
                    });
                    name.innerHTML = item["name"];
                    type.innerHTML = item["type"];
                    price.innerHTML = "$" + item["price"];
                }
            })
            .catch((error) => {
                console.error("Error: ", error);
            });
    }
    function getProductById(productId) {
        let container = id("product-detail-container");
        container.style.display = "block";
        container.style.backgroundColor = "lightblue";

        let closeButton = id("detail-close");
        closeButton.addEventListener("click", function () {
            container.style.display = "none";
        });
        let div = document.getElementById("product-detail");
        div.innerHTML = null;
        fetch(MY_SERVER_BASEURL + "/id/" + productId, function (event) { })
            .then(checkStatus)
            .then((response) => {
                let productId = document.createElement("p");
                let productName = document.createElement("p");
                let productType = document.createElement("p");
                let productPrice = document.createElement("p");
                let productDescription = document.createElement("p");
                productId.innerHTML = "ID: " + response["id"];
                productName.innerHTML = "Name: " + response["name"];
                productType.innerHTML = "Type: " + response["type"];
                productPrice.innerHTML = "Price: " + "$" + response["price"];
                productDescription.innerHTML = "Type: " + response["description"];

                div.appendChild(productId);
                div.appendChild(productName);
                div.appendChild(productType);
                div.appendChild(productPrice);
                div.appendChild(productDescription);

                let rule = document.createElement("hr");
                div.appendChild(rule);
            })
            .catch((error) => {
                console.error("Error: ", error);
            });
    }


    let newButton = id("new-product-btn");
    newButton.addEventListener("click", function () {
        id("form-popup").style.display = "block";
    });
    let saveButton = id("save-product");
    saveButton.addEventListener("click", function (e) {
        e.preventDefault();
        submitForm();
    });
    let closeButton = id("cancel-btn");
    closeButton.addEventListener("click", function (e) {
        id("form-container").reset();
        id("form-popup").style.display = "none";
    });
    function submitForm() {
        let params = new FormData(id("form-container")); // pass in entire form tag
        let jsonBody = JSON.stringify(Object.fromEntries(params)); //make form data json string.
        //let corsUrl = 'http://cors-anywhere.herokuapp.com/' + POST_BASEURL;
        fetch(MY_SERVER_BASEURL + "/new", {
            method: "POST",
            headers: {
                Accept: "application/json, text/plain, */*",
                "Content-Type": "application/json",
            },
            body: jsonBody,
        })
            .then(checkStatus)
            //.then(console.log)
            .then(refreshTable)
            .catch(alert);
    }
    function refreshTable() {
        document.querySelectorAll("td").forEach((element) => {
            element.remove();
        });
        id("form-popup").style.display = "none";
        id("form-container").reset();
        getAllProducts();
    }

    //helper functions
    function id(idName) {
        return document.getElementById(idName);
    }

    function checkStatus(response) {
        if (!response.ok) {
            throw Error("Error in request: " + response.statusText);
        }
        return response.json();
    }
})();
