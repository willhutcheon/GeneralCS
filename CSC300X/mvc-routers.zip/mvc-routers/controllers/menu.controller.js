"use strict";

const express = require("express");
const app = express();

const multer = require("multer");
app.use(multer().none());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const model = require("../models/menu.model");

function getAll(req, res, next) {
  try {
    res.json(model.getAll());
  } catch (err) {
    console.error("Error while getting menu ", err.message);
    next(err);
  }
}

function getAllByCategory(req, res, next) {
  try {
    res.json(model.getAllByCategory(req.params.category));
  } catch (err) {
    console.error("Error while getting menu ", err.message);
    next(err);
  }
}

function getOneById(req, res, next) {
  try {
    res.json(model.getOneById(req.params.id));
  } catch (err) {
    console.error("Error while getting menu ", err.message);
    next(err);
  }
}

function createNew(req, res, next) {
  let id = parseInt(req.body.id);
  let name = req.body.name;
  let category = req.body.category;
  let subcategory = req.body.subcategory;
  let price = parseFloat(req.body.price);
  let cost = parseFloat(req.body.cost);
  if (id && name && category && subcategory && price && cost) {
    let params = [id, name, category, subcategory, price, cost];
    try {
      res.json(model.createNew(params));
    } catch (err) {
      console.error("Error while creating menu ", err.message);
      next(err);
    }
  }
}


function searchMenu(term, callback) {
  let sql = "SELECT name, price FROM menu WHERE name LIKE ?;";
  db.all(sql, [`%${term}%`], callback);
}

/* function searchMenu(req, res, next) {
  try {
    const term = req.query.term;
    model.searchMenu(term, (err, results) => {
      if (err) {
        console.error("Error while searching menu", err.message);
        return next(err);
      }
      res.json(results);
    });
  } catch (err) {
    console.error("Error while searching menu", err.message);
    next(err);
  }
} */

module.exports = {
  getAll,
  getAllByCategory,
  getOneById,
  createNew,
  searchMenu,
};
